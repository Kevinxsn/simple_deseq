
# THIS FILE IS GENERATED FROM SETUP.PY
version = '1.0.0'
__version__ = version